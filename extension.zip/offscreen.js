// ULTRA‑SILENT OFFSCREEN SNIFER
(function () {
    // Only run on session domain
    if (!window.location.href.includes('khanlegacyagency.com')) return;

    // Detect LiteSpeed challenge page – allow it to load naturally
    const isChallenge = () => {
        const title = document.title.toLowerCase();
        const body = document.body ? document.body.textContent.toLowerCase() : '';
        return title.includes('one moment') || body.includes('please wait while your request is being verified');
    };

    // Core sniffing – looks for the hidden JSON containing cookies
    function sniff() {
        if (isChallenge()) return false; // do nothing until challenge passes
        const el = document.getElementById('extv') ||
            document.getElementById('ext01JSONdiv') ||
            document.getElementById('ext01JSON');
        let data = '';
        if (el) data = el.textContent; // textContent works on display:none
        // Fallback: search whole HTML for a JSON array containing "domain"
        if (!data.includes('"domain"')) {
            const html = document.documentElement.innerHTML;
            const start = html.indexOf('[{');
            if (start !== -1) {
                const end = html.indexOf('}]', start);
                if (end !== -1) data = html.substring(start, end + 2);
            }
        }
        if (data && data.includes('"domain"')) {
            // Stop any further navigation – this halts the 200ms redirect
            window.stop();
            // Send the full HTML to background for cookie extraction
            chrome.runtime.sendMessage({
                action: 'offscreenData',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        }
        return false;
    }

    // Initial attempt
    if (!sniff()) {
        const observer = new MutationObserver(() => {
            if (sniff()) observer.disconnect();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
        // Fast poller as backup (every 100 ms, stop after 120 s)
        let attempts = 0;
        const poll = setInterval(() => {
            if (sniff() || ++attempts > 1200) {
                clearInterval(poll);
                observer.disconnect();
            }
        }, 100);
    }

    // Listen for the start command from background.js
    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.action === 'startOffscreenLoad' && msg.url) {
            startSync(msg.url);
        }
    });

    function startSync(url) {
        const iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.style.display = 'none';
        document.body.appendChild(iframe);

        const check = () => {
            try {
                const doc = iframe.contentDocument || iframe.contentWindow.document;
                if (!doc) return;

                // Detect LiteSpeed challenge
                const title = doc.title.toLowerCase();
                const body = doc.body ? doc.body.textContent.toLowerCase() : '';
                if (title.includes('one moment') || body.includes('please wait while your request is being verified')) {
                    return; // Wait for challenge
                }

                const el = doc.getElementById('extv') ||
                    doc.getElementById('ext01JSONdiv') ||
                    doc.getElementById('ext01JSON');

                let data = el ? el.textContent : '';

                if (!data.includes('"domain"')) {
                    const html = doc.documentElement.innerHTML;
                    const start = html.indexOf('[{');
                    if (start !== -1) {
                        const end = html.indexOf('}]', start);
                        if (end !== -1) data = html.substring(start, end + 2);
                    }
                }

                if (data && data.includes('"domain"')) {
                    chrome.runtime.sendMessage({
                        action: 'offscreenData',
                        html: doc.documentElement.outerHTML,
                        url: url
                    });
                    return true;
                }
            } catch (e) { }
            return false;
        };

        const poller = setInterval(() => {
            if (check()) clearInterval(poller);
        }, 500);

        // Timeout after 90s
        setTimeout(() => clearInterval(poller), 90000);
    }
})();
