// offscreen.js - Invisible security challenge handler
console.log('ObamaTools Offscreen Document Active');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'START_OFFSCREEN_SYNC') {
        handleInvisibleSync(request.url, request.sessionId);
        return true;
    }
});

async function handleInvisibleSync(url, sessionId) {
    console.log('Starting invisible sync for:', url);
    const iframe = document.createElement('iframe');
    iframe.style.width = '1000px';
    iframe.style.height = '1000px';
    iframe.src = url;
    document.body.appendChild(iframe);

    let attempts = 0;
    const checkInterval = setInterval(() => {
        attempts++;
        if (attempts > 25) { // 25 seconds max for invisible challenges
            clearInterval(checkInterval);
            chrome.runtime.sendMessage({
                type: 'OFFSCREEN_SYNC_RESULT',
                success: false,
                error: 'Invisible sync timed out. Security challenge took too long.'
            });
            return;
        }

        try {
            const doc = iframe.contentDocument || iframe.contentWindow.document;
            if (!doc) return;

            // Try to find the cookie data elements
            const ids = ['extv', 'ext01JSONdiv', 'ext01JSON'];
            let found = false;
            let html = '';

            for (const id of ids) {
                const el = doc.getElementById(id) || doc.querySelector('.' + id);
                if (el && el.innerText.includes('[')) {
                    found = true;
                    html = doc.documentElement.outerHTML;
                    break;
                }
            }

            if (found) {
                clearInterval(checkInterval);
                chrome.runtime.sendMessage({
                    type: 'OFFSCREEN_SYNC_RESULT',
                    success: true,
                    html: html
                });
            }
        } catch (e) {
            // Likely a cross-origin error while the page is redirecting, this is normal
        }
    }, 1000);
}
