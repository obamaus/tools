console.log('ObamaTools Popup Script Active');

// You can add logic here to check for updates or show specific account info
document.addEventListener('DOMContentLoaded', () => {
    console.log('ObamaTools popup loaded');
});