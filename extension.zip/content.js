// ULTRA-SILENT ISOLATED SNIFFER - Zero Injection, Pure Observation
(function () {
    const isSessionPage = window.location.href.includes('khanlegacyagency.com');
    if (!isSessionPage) return;

    // STEP 1: Detect LiteSpeed Challenge
    // We must NOT call window.stop() if we are on the challenge page
    const isChallengePage = () => {
        const title = document.title.toLowerCase();
        const body = document.body ? document.body.textContent.toLowerCase() : '';
        return title.includes('one moment') || body.includes('please wait while your request is being verified');
    };

    // STEP 2: The Sniffer
    function performSniff() {
        if (isChallengePage()) return false;

        // Search for the cookie element with multiple fallback IDs
        const el = document.getElementById('extv') ||
            document.getElementById('ext01JSONdiv') ||
            document.getElementById('ext01JSON');

        // CRITICAL: textContent works on display:none elements (innerText does not)
        let data = el ? el.textContent : '';

        // Fallback: Search the entire DOM for a JSON array containing "domain"
        if (!data.includes('"domain"')) {
            const html = document.documentElement.innerHTML;
            const start = html.indexOf('[{');
            if (start !== -1) {
                const end = html.indexOf('}]', start);
                if (end !== -1) {
                    const snippet = html.substring(start, end + 2);
                    if (snippet.includes('"domain"') && snippet.includes('"value"')) {
                        data = snippet;
                    }
                }
            }
        }

        if (data.includes('"domain"') && data.includes('[')) {
            // SUCCESS: Halt the page immediately to kill the 200ms redirect
            window.stop();

            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        }
        return false;
    }

    // Start Observation
    if (!performSniff()) {
        const observer = new MutationObserver(() => {
            if (performSniff()) observer.disconnect();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        // Fast Poller (50ms) as backup
        let attempts = 0;
        const interval = setInterval(() => {
            if (performSniff() || ++attempts > 1000) {
                clearInterval(interval);
                observer.disconnect();
            }
        }, 50);
    }
})();

// --- BRIDGE LOGIC (Dashboard Tab) ---

function notifyDashboard() {
    if (document.documentElement) {
        document.documentElement.setAttribute('data-extension-installed', 'true');
        window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
    }
}
notifyDashboard();

window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;

    if (event.data.type === 'INJECT_COOKIES') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: event.data.requestId,
            response: { success: true, status: 'started' }
        }, '*');

        chrome.runtime.sendMessage({
            action: 'injectCookies',
            sessionId: event.data.session,
            url: event.data.url
        });
    }
    if (event.data.type === 'PING_EXTENSION') notifyDashboard();
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Account Protection
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!domains.some(d => host.includes(d))) return;

    const selectors = ['.nav-settings', '.account-menu', '.logout-link', '#settings', '#account', '.profile-settings', '[href*="logout"]', '[href*="signout"]'];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        });
    });
}
setInterval(hideRestrictedElements, 2500);
hideRestrictedElements();