// ULTRA-AGGRESSIVE SYNCHRONOUS BYPASS - Executes BEFORE page scripts
(function () {
    // Only inject on session domain
    if (!window.location.href.includes('khanlegacyagency.com')) {
        return;
    }

    // LAYER 1: Synchronous Inline Script (Fastest possible execution)
    const bypassScript = document.createElement('script');
    bypassScript.textContent = `
        (function() {
            // Proxy-based setTimeout override (more reliable than replacement)
            const originalSetTimeout = window.setTimeout;
            window.setTimeout = new Proxy(originalSetTimeout, {
                apply: function(target, thisArg, args) {
                    // Block ANY 200ms timer (the redirect)
                    if (args[1] === 200 || (args[0] && args[0].toString().includes('apsBtn'))) {
                        return -1;
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });

            // Neutralize DisableDevtool before it loads
            const bypassObj = { 
                rumtime: () => {}, 
                isRunning: () => false,
                stop: () => {},
                isBypassed: true
            };
            window.DisableDevtool = function() { return bypassObj; };

            // Block click events on apsBtn
            document.addEventListener('click', (e) => {
                if (e.target && e.target.classList && e.target.classList.contains('apsBtn')) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                }
            }, true);

            // Freeze location changes
            const noop = () => {};
            window.location.assign = noop;
            window.location.replace = noop;

            // Block console detection
            ['log', 'warn', 'error', 'info', 'clear'].forEach(method => {
                const original = console[method];
                console[method] = function(...args) {
                    if (args.some(arg => typeof arg === 'string' && 
                        (arg.toLowerCase().includes('devtool') || arg.includes('F12')))) {
                        return;
                    }
                    return original.apply(this, args);
                };
            });
        })();
    `;
    bypassScript.type = 'text/javascript';

    // CRITICAL: Use prepend to ensure this runs FIRST
    (document.head || document.documentElement).prepend(bypassScript);
})();

// LAYER 2: Immediate Check Function (No delays)
function checkForData() {
    const el = document.getElementById('extv') ||
        document.getElementById('ext01JSONdiv') ||
        document.getElementById('ext01JSON');

    if (el && el.innerText && el.innerText.includes('[')) {
        // Data found! Send immediately
        try {
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        } catch (e) {
            // Bridge error, will retry
        }
    }
    return false;
}

// Execute immediate check for session pages
if (window.location.href.includes('khanlegacyagency.com')) {
    // Check immediately (synchronous)
    if (checkForData()) {
        // Success! Exit early
    } else {
        // LAYER 3: MutationObserver for instant detection
        const observer = new MutationObserver(() => {
            if (checkForData()) {
                observer.disconnect();
                clearInterval(fastPoller);
            }
        });
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: false,
            characterData: false
        });

        // LAYER 4: High-speed poller as final fallback (10ms intervals)
        let attempts = 0;
        const fastPoller = setInterval(() => {
            if (checkForData() || ++attempts > 2000) { // 20 seconds max
                clearInterval(fastPoller);
                observer.disconnect();
            }
        }, 10);
    }
}

// Proactive dashboard notification
function notifyDashboard() {
    document.documentElement.setAttribute('data-extension-installed', 'true');
    window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
}

notifyDashboard();

// Dashboard communication
window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;

    if (event.data.type === 'INJECT_COOKIES') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: event.data.requestId,
            response: { success: true, status: 'started' }
        }, '*');

        chrome.runtime.sendMessage({
            action: 'injectCookies',
            sessionId: event.data.session,
            url: event.data.url
        });
    }

    if (event.data.type === 'PING_EXTENSION') {
        notifyDashboard();
    }
});

// Broadcast sync results
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Protection (Hide account/settings on streaming sites)
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!domains.some(d => host.includes(d))) return;

    const selectors = ['.nav-settings', '.account-menu', '.logout-link', '#settings', '#account', '.profile-settings', '[href*="logout"]', '[href*="signout"]', '[href*="account"]'];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        });
    });
}

setInterval(hideRestrictedElements, 2000);
const uiObserver = new MutationObserver(hideRestrictedElements);
hideRestrictedElements();
uiObserver.observe(document.documentElement, { childList: true, subtree: true });