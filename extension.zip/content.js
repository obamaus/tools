function injectBypass() {
    const code = `
        (function() {
            // 1. Override the DisableDevtool constructor before it even loads
            const bypassObj = {
                rumtime: function() {},
                isRunning: function() { return false; },
                clearIntervalWhenDevOpenTrigger: function() {},
                stop: function() {},
                isBypassed: true
            };

            window.DisableDevtool = function() {
                return bypassObj;
            };

            // 2. Override prototype methods
            if (window.DisableDevtool && window.DisableDevtool.prototype) {
                window.DisableDevtool.prototype.rumtime = function() {};
                window.DisableDevtool.prototype.isRunning = function() { return false; };
            }

            // 3. Prevent detection events
            const originalAddEventListener = EventTarget.prototype.addEventListener;
            EventTarget.prototype.addEventListener = function(type, listener, options) {
                if (typeof type === 'string' && 
                    (type.toLowerCase().includes('devtools') || 
                     type.toLowerCase().includes('developer'))) {
                    return;
                }
                return originalAddEventListener.call(this, type, listener, options);
            };

            // 4. Freeze console filtering to keep it clean
            const originalConsole = { ...console };
            ['log', 'warn', 'error', 'info'].forEach(method => {
                const original = console[method];
                console[method] = function(...args) {
                    const hasDetectionMsg = args.some(arg => 
                        typeof arg === 'string' && 
                        (arg.toLowerCase().includes('devtool') || 
                         arg.toLowerCase().includes('developer tool') ||
                         arg.includes('F12') ||
                         arg.includes('Ctrl+Shift+I')));
                    
                    if (hasDetectionMsg) return;
                    return original.apply(this, args);
                };
            });

            // 5. Intercept the 200ms redirect from Netflix.php
            const originalAssign = window.location.assign;
            const originalReplace = window.location.replace;
            
            // Only unblock on the session domain
            if (window.location.hostname.includes('khanlegacyagency.com')) {
                // Swallow location changes briefly to allow extraction
                window.location.assign = function(url) { };
                window.location.replace = function(url) { };
                
                // Block form submissions or button clicks that redirect
                document.addEventListener('click', (e) => {
                    if (e.target.classList && e.target.classList.contains('apsBtn')) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                }, true);
            }
        })();
    `;
    const script = document.createElement('script');
    script.textContent = code;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
}

// Execute bypass immediately at document_start
injectBypass();

function notifyDashboard() {
    document.documentElement.setAttribute('data-extension-installed', 'true');
    window.postMessage({
        type: 'EXTENSION_READY',
        installed: true
    }, '*');
}

notifyDashboard();

// Sniffer logic (isolated world)
if (window.location.href.includes('khanlegacyagency.com')) {
    let attempts = 0;
    const fastSniffer = setInterval(() => {
        attempts++;
        if (attempts > 300) { // 15 seconds
            clearInterval(fastSniffer);
            return;
        }

        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    }, 50);

    const observer = new MutationObserver((mutations) => {
        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            observer.disconnect();
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
}

// Shared listeners
window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const request = event.data;
    if (!request || !request.type) return;

    if (request.type === 'INJECT_COOKIES') {
        try {
            window.postMessage({
                type: 'EXTENSION_RESPONSE',
                requestId: request.requestId,
                response: { success: true, status: 'started' }
            }, '*');

            chrome.runtime.sendMessage({
                action: 'injectCookies',
                sessionId: request.session,
                url: request.url
            });
        } catch (e) {
            window.postMessage({
                type: 'EXTENSION_RESPONSE',
                requestId: request.requestId,
                response: { success: false, error: 'Extension connection lost. Please refresh.' }
            }, '*');
        }
    }

    if (request.type === 'PING_EXTENSION') {
        notifyDashboard();
    }
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Protection logic
const HIDE_SELECTORS = [
    '.nav-settings', '.account-menu', '.logout-link',
    '#settings', '#account', '.profile-settings',
    '[href*="logout"]', '[href*="signout"]', '[href*="account"]',
    '.manage-profiles', '.edit-profile', '.css-vub46n',
    'button[aria-label="Account menu"]', 'a[href*="/settings"]'
];

function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const SUPPORTED_DOMAINS = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!SUPPORTED_DOMAINS.some(d => host.includes(d))) return;

    HIDE_SELECTORS.forEach(selector => {
        document.querySelectorAll(selector).forEach(el => {
            if (el.style.display !== 'none') {
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
            }
        });
    });
}

let checks = 0;
const checkTimer = setInterval(() => {
    hideRestrictedElements();
    if (++checks > 10) {
        clearInterval(checkTimer);
        setInterval(hideRestrictedElements, 2000);
    }
}, 500);

const uiObserver = new MutationObserver(hideRestrictedElements);
uiObserver.observe(document.documentElement, { childList: true, subtree: true });