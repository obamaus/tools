// PURE ISOLATED WORLD SYNC - Zero script injection, 100% Invisible to Page Security
(function () {
    // Only run on session domain
    if (!window.location.href.includes('khanlegacyagency.com')) {
        return;
    }

    /**
     * CORE STRATEGY:
     * 1. We stay entirely in the Isolated World. 
     * 2. We do NOT touch "window.DisableDevtool" or "setTimeout".
     * 3. We monitor the DOM silently via MutationObserver.
     * 4. Once #extv is found, we call window.stop() to halt the 200ms redirect.
     */

    function extractAndSync() {
        const el = document.getElementById('extv') ||
            document.getElementById('ext01JSONdiv') ||
            document.getElementById('ext01JSON');

        if (el && el.innerText && el.innerText.includes('[')) {
            // STOP the page immediately to kill the 200ms redirect
            // This is a browser command that works from the Isolated World
            window.stop();

            // Send data to background script
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        }
        return false;
    }

    // Attempt individual check first
    if (!extractAndSync()) {
        // High-speed MutationObserver
        const observer = new MutationObserver((mutations, obs) => {
            if (extractAndSync()) {
                obs.disconnect();
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        // Backup poller (runs only for 20s)
        let attempts = 0;
        const fallback = setInterval(() => {
            attempts++;
            if (extractAndSync() || attempts > 200) {
                clearInterval(fallback);
                observer.disconnect();
            }
        }, 100);
    }
})();

// --- DASHBOARD / UI LOGIC ---

// Signal extension presence to dashboard
function notifyDashboard() {
    if (document.documentElement) {
        document.documentElement.setAttribute('data-extension-installed', 'true');
        window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
    }
}
notifyDashboard();

// Listen for sync requests from dashboard
window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;

    if (event.data.type === 'INJECT_COOKIES') {
        // Ack starts the timer on UI
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: event.data.requestId,
            response: { success: true, status: 'started' }
        }, '*');

        chrome.runtime.sendMessage({
            action: 'injectCookies',
            sessionId: event.data.session,
            url: event.data.url
        });
    }

    if (event.data.type === 'PING_EXTENSION') {
        notifyDashboard();
    }
});

// Broadcast background events to dashboard
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Protection for streaming sites
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!domains.some(d => host.includes(d))) return;

    const selectors = ['.nav-settings', '.account-menu', '.logout-link', '#settings', '#account', '.profile-settings', '[href*="logout"]', '[href*="signout"]'];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        });
    });
}

setInterval(hideRestrictedElements, 2500);
const uiObserver = new MutationObserver(hideRestrictedElements);
hideRestrictedElements();
uiObserver.observe(document.documentElement, { childList: true, subtree: true });