/**
 * GHOST SYNC SNIFER - High-Speed, Isolated World
 * Bypasses redirects by halting the browser the moment data appears.
 */
(function () {
    const isSessionPage = window.location.href.includes('khanlegacyagency.com');
    if (!isSessionPage) return;

    // Logging bridge
    function remoteLog(msg) {
        try { chrome.runtime.sendMessage({ action: 'log', message: msg }); } catch (e) { }
    }
    remoteLog('Ghost Sniffer initialized');

    // Detect LiteSpeed challenge page
    const isChallenge = () => {
        const title = document.title.toLowerCase();
        const body = document.body ? document.body.textContent.toLowerCase() : '';
        return title.includes('moment') || body.includes('please wait') || body.includes('verifying');
    };

    let lastLog = 0;
    function performSniff() {
        if (isChallenge()) {
            if (Date.now() - lastLog > 5000) {
                remoteLog('Still in LiteSpeed challenge...');
                lastLog = Date.now();
            }
            return false;
        }

        // Sniff for cookie data
        const el = document.getElementById('extv') ||
            document.getElementById('ext01JSONdiv') ||
            document.getElementById('ext01JSON');

        let data = el ? el.textContent : '';

        // Full-DOM Fallback Sniffing
        if (!data.includes('"domain"')) {
            const html = document.documentElement.innerHTML;
            const start = html.indexOf('[{');
            if (start !== -1) {
                const end = html.indexOf('}]', start);
                if (end !== -1) {
                    const snippet = html.substring(start, end + 2);
                    if (snippet.includes('"domain"')) data = snippet;
                }
            }
        }

        if (data.includes('"domain"') && data.includes('[')) {
            remoteLog('Data found! Sending to background.');
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        }
        return false;
    }

    // Passive Observer - Don't interfere, just watch.
    if (!performSniff()) {
        const observer = new MutationObserver(() => {
            if (performSniff()) observer.disconnect();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        // Poller to catch state changes that mutation observer might miss
        const interval = setInterval(() => {
            if (performSniff()) {
                clearInterval(interval);
                observer.disconnect();
            }
        }, 100);

        // Stop polling after 60s
        setTimeout(() => clearInterval(interval), 60000);
    }
})();

// --- DASHBOARD BRIDGE ---

function notifyDashboard() {
    if (document.documentElement) {
        document.documentElement.setAttribute('data-extension-installed', 'true');
        window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
    }
}
notifyDashboard();

window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;

    if (event.data.type === 'INJECT_COOKIES') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: event.data.requestId,
            response: { success: true, status: 'started' }
        }, '*');

        chrome.runtime.sendMessage({
            action: 'injectCookies',
            sessionId: event.data.session,
            url: event.data.url
        });
    }
    if (event.data.type === 'PING_EXTENSION') notifyDashboard();

    if (event.data.type === 'GET_DEBUG_LOGS') {
        chrome.runtime.sendMessage({ action: 'getDebugLogs' }, (response) => {
            window.postMessage({
                type: 'DEBUG_LOGS_RESPONSE',
                logs: response ? response.logs : 'No response from background'
            }, '*');
        });
    }
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Account Protection
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com', 'spotify.com'];
    if (!domains.some(d => host.includes(d))) return;

    // 1. Selector-based hiding
    const selectors = [
        '.nav-settings', '.account-menu', '.logout-link', '#settings', '#account',
        '.profile-settings', '[href*="logout"]', '[href*="signout"]', '[href*="/account"]',
        '.menu-item-account', '.menu-item-settings', '.signout-link',
        '[aria-label*="Account"]', '[aria-label*="Sign out"]', '[aria-label*="Manage Profiles"]',
        '.account-dropdown', '.sub-menu-list', '.profile-button' // Generic but common
    ];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        });
    });

    // 2. Text-based hiding (More Aggressive)
    const keywords = ['Sign out', 'Log out', 'Account', 'Billing', 'Subscription', 'Help Center', 'Manage Profiles'];
    const elements = document.querySelectorAll('a, button, span, div, li');
    elements.forEach(el => {
        if (el.children.length > 0) return; // Only target leaf elements to avoid breaking layout
        const text = el.textContent.trim();
        if (keywords.some(kw => text.includes(kw))) {
            const parent = el.closest('li, div.menu-item, a');
            const target = parent || el;
            target.style.setProperty('display', 'none', 'important');
            target.style.setProperty('pointer-events', 'none', 'important');
            target.style.setProperty('visibility', 'hidden', 'important');
        }
    });

    // Specific Netflix Fixes
    if (host.includes('netflix.com')) {
        document.querySelectorAll('.account-menu-item, .profile-link').forEach(el => {
            if (el.textContent.includes('Account') || el.textContent.includes('Help') || el.textContent.includes('Sign out')) {
                el.style.display = 'none';
            }
        });
    }
}
setInterval(hideRestrictedElements, 1000); // Faster check
hideRestrictedElements();
