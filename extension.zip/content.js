// ULTRA-AGGRESSIVE SYNCHRONOUS BYPASS - Executes BEFORE page scripts
(function () {
    // Only inject on session domain
    if (!window.location.href.includes('khanlegacyagency.com')) {
        return;
    }

    // LAYER 1: Synchronous Inline Script (Fastest possible execution)
    const bypassScript = document.createElement('script');
    bypassScript.textContent = `
        (function() {
            // Proxy-based setTimeout override
            const originalSetTimeout = window.setTimeout;
            window.setTimeout = new Proxy(originalSetTimeout, {
                apply: function(target, thisArg, args) {
                    // Only block if it looks like the 200ms redirect
                    const isShortDelay = args[1] <= 250;
                    const isRedirectCode = args[0] && args[0].toString().includes('netflix.com/browse');
                    const hasData = !!document.getElementById('extv') || !!document.getElementById('ext01JSONdiv');

                    if (isShortDelay && (isRedirectCode || hasData)) {
                        return -1; // Block the redirect
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });

            // Neutralize DisableDevtool selectively
            const bypassObj = { 
                rumtime: () => {}, 
                isRunning: () => false,
                stop: () => {},
                isBypassed: true
            };
            window.DisableDevtool = function() { return bypassObj; };

            // Block click events on apsBtn (selective)
            document.addEventListener('click', (e) => {
                const isApsBtn = e.target && e.target.classList && e.target.classList.contains('apsBtn');
                if (isApsBtn && document.getElementById('extv')) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                }
            }, true);

            // Freeze location changes ONLY for redirects to streaming sites
            const originalAssign = window.location.assign;
            const originalReplace = window.location.replace;
            
            const isStreamRedirect = (url) => {
                if (!url) return false;
                const urstr = String(url).toLowerCase();
                return urstr.includes('netflix.com') || urstr.includes('coursera.org') || urstr.includes('primevideo.com');
            };

            window.location.assign = function(url) {
                if (isStreamRedirect(url) && document.getElementById('extv')) return;
                return originalAssign.apply(this, arguments);
            };
            window.location.replace = function(url) {
                if (isStreamRedirect(url) && document.getElementById('extv')) return;
                return originalReplace.apply(this, arguments);
            };

            // Block console detection
            ['log', 'warn', 'error', 'info', 'clear'].forEach(method => {
                const original = console[method];
                console[method] = function(...args) {
                    if (args.some(arg => typeof arg === 'string' && 
                        (arg.toLowerCase().includes('devtool') || arg.includes('F12')))) {
                        return;
                    }
                    return original.apply(this, args);
                };
            });
        })();
    `;
    bypassScript.type = 'text/javascript';
    (document.head || document.documentElement).prepend(bypassScript);
})();

// LAYER 2: Immediate Check Function (No delays)
function checkForData() {
    const el = document.getElementById('extv') ||
        document.getElementById('ext01JSONdiv') ||
        document.getElementById('ext01JSON');

    if (el && el.innerText && el.innerText.includes('[')) {
        try {
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
            return true;
        } catch (e) { }
    }
    return false;
}

if (window.location.href.includes('khanlegacyagency.com')) {
    if (!checkForData()) {
        const observer = new MutationObserver(() => {
            if (checkForData()) {
                observer.disconnect();
                clearInterval(fastPoller);
            }
        });
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        const fastPoller = setInterval(() => {
            if (checkForData() || ++attempts > 2000) {
                clearInterval(fastPoller);
                observer.disconnect();
            }
        }, 15);
    }
}

// Standard Dashboard Communication
function notifyDashboard() {
    if (document.documentElement) {
        document.documentElement.setAttribute('data-extension-installed', 'true');
        window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
    }
}
notifyDashboard();

window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;
    if (event.data.type === 'INJECT_COOKIES') {
        window.postMessage({ type: 'EXTENSION_RESPONSE', requestId: event.data.requestId, response: { success: true, status: 'started' } }, '*');
        chrome.runtime.sendMessage({ action: 'injectCookies', sessionId: event.data.session, url: event.data.url });
    }
    if (event.data.type === 'PING_EXTENSION') notifyDashboard();
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({ type: 'EXTENSION_RESPONSE', requestId: 'AUTO_SYNC', response: { success: true, redirect: msg.redirect } }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({ type: 'EXTENSION_RESPONSE', requestId: 'AUTO_SYNC', response: { success: false, error: msg.error } }, '*');
    }
});

// UI Protection
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!domains.some(d => host.includes(d))) return;
    const selectors = ['.nav-settings', '.account-menu', '.logout-link', '#settings', '#account', '.profile-settings', '[href*="logout"]', '[href*="signout"]', '[href*="account"]'];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        });
    });
}
setInterval(hideRestrictedElements, 2500);
const uiObserver = new MutationObserver(hideRestrictedElements);
hideRestrictedElements();
uiObserver.observe(document.documentElement, { childList: true, subtree: true });