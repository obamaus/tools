function notifyDashboard() {
    document.documentElement.setAttribute('data-extension-installed', 'true');
    window.postMessage({
        type: 'EXTENSION_READY',
        installed: true
    }, '*');
}

if (window.location.href.includes('khanlegacyagency.com')) {
    // 1. FREEZE the page immediately to stop the 200ms redirect
    try {
        if (window.location.href.includes('Netflix.php') || window.location.href.includes('Coursera.php')) {
            window.stop();
            // Block any future attempts to redirect
            window.location.assign = () => { };
            window.location.replace = () => { };
            Object.defineProperty(window, 'onbeforeunload', { configurable: false, value: () => "Syncing..." });
        }
    } catch (e) { }

    // 2. High-speed sniffer (50ms) to catch the 200ms window
    let attempts = 0;
    const fastSniffer = setInterval(() => {
        attempts++;
        if (attempts > 200) { // 10 seconds of high-speed checking
            clearInterval(fastSniffer);
            return;
        }

        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    }, 50);

    // 3. MutationObserver as a backup for instant detection
    const observer = new MutationObserver((mutations) => {
        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            observer.disconnect();
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
}

// Listen for messages from the web page
window.addEventListener('message', (event) => {
    // Only accept messages from the window itself
    if (event.source !== window) return;

    const request = event.data;
    if (!request || !request.type) return;

    // Handle cookie injection requests
    if (request.type === 'INJECT_COOKIES') {
        try {
            window.postMessage({
                type: 'EXTENSION_RESPONSE',
                requestId: request.requestId,
                response: { success: true, status: 'started' }
            }, '*');

            chrome.runtime.sendMessage({
                action: 'injectCookies',
                sessionId: request.session,
                url: request.url
            });
        } catch (e) {
            window.postMessage({
                type: 'EXTENSION_RESPONSE',
                requestId: request.requestId,
                response: { success: false, error: 'Extension connection lost. Please refresh.' }
            }, '*');
        }
    }

    // Handle health checks
    if (request.type === 'PING_EXTENSION') {
        notifyDashboard();
    }
});

// Listen for messages from background script
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Protection: Hide settings/logout on supported streaming sites
const HIDE_SELECTORS = [
    '.nav-settings', '.account-menu', '.logout-link',
    '#settings', '#account', '.profile-settings',
    '[href*="logout"]', '[href*="signout"]', '[href*="account"]',
    '.manage-profiles', '.edit-profile', '.css-vub46n', // Netflix specific
    'button[aria-label="Account menu"]', 'a[href*="/settings"]'
];

function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();

    // Only run on supported domains
    const SUPPORTED_DOMAINS = [
        'netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com',
        'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'
    ];

    if (!SUPPORTED_DOMAINS.some(d => host.includes(d))) return;

    HIDE_SELECTORS.forEach(selector => {
        document.querySelectorAll(selector).forEach(el => {
            if (el.style.display !== 'none') {
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
            }
        });
    });
}

// Periodically check for new elements
// We use a faster interval initially, then settle to 2s
let checks = 0;
const checkTimer = setInterval(() => {
    hideRestrictedElements();
    if (++checks > 10) {
        clearInterval(checkTimer);
        setInterval(hideRestrictedElements, 2000);
    }
}, 500);

// Also use MutationObserver for efficiency
const observer = new MutationObserver(hideRestrictedElements);
observer.observe(document.documentElement, { childList: true, subtree: true });