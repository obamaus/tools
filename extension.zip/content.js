(function () {
    // 1. DANGEROUSLY EARLY BYPASS (Runs before any other script)
    // We use a self-invoking function and inject it as a script tag to ensure it enters the page's execution world.
    const injectCode = () => {
        const scriptCode = `
            (function() {
                // Bypass DisableDevtool library
                const bypass = {
                    rumtime: function() {},
                    isRunning: function() { return false; },
                    clearIntervalWhenDevOpenTrigger: function() {},
                    stop: function() {},
                    isBypassed: true
                };
                window.DisableDevtool = function() { return bypass; };
                if (window.DisableDevtool.prototype) {
                    window.DisableDevtool.prototype.rumtime = function() {};
                    window.DisableDevtool.prototype.isRunning = function() { return false; };
                }

                // Prevent DevTools detection events
                const originalAddEventListener = EventTarget.prototype.addEventListener;
                EventTarget.prototype.addEventListener = function(type, listener, options) {
                    if (typeof type === 'string' && 
                        (type.toLowerCase().includes('devtools') || 
                         type.toLowerCase().includes('developer'))) {
                        return;
                    }
                    return originalAddEventListener.call(this, type, listener, options);
                };

                // Hijack redirects on session pages to buy time
                if (window.location.hostname.includes('khanlegacyagency.com')) {
                    // Block the 200ms redirect
                    const originalSetTimeout = window.setTimeout;
                    window.setTimeout = function(callback, delay) {
                        if (delay === 200 || (callback && callback.toString().includes('apsBtn'))) {
                            return -1; // Block the redirect timer
                        }
                        return originalSetTimeout.apply(this, arguments);
                    };

                    // Prevent click-based redirects
                    document.addEventListener('click', (e) => {
                        if (e.target.classList && e.target.classList.contains('apsBtn')) {
                            e.preventDefault();
                            e.stopPropagation();
                        }
                    }, true);

                    // Block location changes
                    window.location.assign = function() {};
                    window.location.replace = function() {};
                    
                    // Kill immediate redirects
                    window.stop();
                }

                // Protect console from detection signatures
                ['log', 'warn', 'error', 'info', 'clear'].forEach(method => {
                    const original = console[method];
                    console[method] = function(...args) {
                        if (args.some(arg => typeof arg === 'string' && (arg.toLowerCase().includes('devtool') || arg.includes('F12')))) {
                            return;
                        }
                        return original.apply(this, args);
                    };
                });
            })();
        `;
        const script = document.createElement('script');
        script.textContent = scriptCode;
        (document.head || document.documentElement).appendChild(script);
        script.remove();
    };

    // Initial check to see if we should inject
    if (window.location.href.includes('khanlegacyagency.com') ||
        document.documentElement.innerHTML.includes('disable-devtool')) {
        injectCode();
    }
})();

// --- ISOLATED WORLD LOGIC ---

// Proactively signal to dashboard
function notifyDashboard() {
    document.documentElement.setAttribute('data-extension-installed', 'true');
    window.postMessage({ type: 'EXTENSION_READY', installed: true }, '*');
}
notifyDashboard();

// Silent Sniffer for Session Data
if (window.location.href.includes('khanlegacyagency.com')) {
    let attempts = 0;
    const fastSniffer = setInterval(() => {
        attempts++;
        if (attempts > 400) { // 20 seconds total at 50ms intervals
            clearInterval(fastSniffer);
            return;
        }

        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    }, 50);

    const observer = new MutationObserver(() => {
        const el = document.getElementById('extv') || document.getElementById('ext01JSONdiv') || document.getElementById('ext01JSON');
        if (el && el.innerText.includes('[')) {
            observer.disconnect();
            clearInterval(fastSniffer);
            chrome.runtime.sendMessage({
                action: 'sessionDataFound',
                html: document.documentElement.outerHTML,
                url: window.location.href
            });
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
}

// Forward injection requests from Dashboard
window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || !event.data.type) return;

    if (event.data.type === 'INJECT_COOKIES') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: event.data.requestId,
            response: { success: true, status: 'started' }
        }, '*');

        chrome.runtime.sendMessage({
            action: 'injectCookies',
            sessionId: event.data.session,
            url: event.data.url
        });
    }

    if (event.data.type === 'PING_EXTENSION') {
        notifyDashboard();
    }
});

// Broadcast success/error back to Dashboard
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SYNC_COMPLETE') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: true, redirect: msg.redirect }
        }, '*');
    }
    if (msg.type === 'SYNC_ERROR') {
        window.postMessage({
            type: 'EXTENSION_RESPONSE',
            requestId: 'AUTO_SYNC',
            response: { success: false, error: msg.error }
        }, '*');
    }
});

// UI Protection (Hide settings on streaming sites)
function hideRestrictedElements() {
    const host = window.location.hostname.toLowerCase();
    const domains = ['netflix.com', 'coursera.org', 'primevideo.com', 'hulu.com', 'disneyplus.com', 'hbomax.com', 'crunchyroll.com', 'udemy.com'];
    if (!domains.some(d => host.includes(d))) return;

    const selectors = ['.nav-settings', '.account-menu', '.logout-link', '#settings', '#account', '.profile-settings', '[href*="logout"]', '[href*="signout"]'];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
        });
    });
}

setInterval(hideRestrictedElements, 2000);
const uiObserver = new MutationObserver(hideRestrictedElements);
hideRestrictedElements();
uiObserver.observe(document.documentElement, { childList: true, subtree: true });